<?php
// Start a session
session_start();

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
  header('Location: index2.php');
  exit();
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Get the form data
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Validate the form data
  $errors = [];
  if (empty($email)) {
    $errors[] = 'Please enter your email address.';
  } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please enter a valid email address.';
  }
  if (empty($password)) {
    $errors[] = 'Please enter a password.';
  }

  // If there are no errors, check the user's credentials
  if (empty($errors)) {
    // Connect to the database (replace "hostname", "username", "password", and "database" with your own values)
    $conn = mysqli_connect('localhost', 'root', '', 'pg');

    // Check if the connection was successful
    if (!$conn) {
      die('Database connection error: ' . mysqli_connect_error());
    }

    // Query the "users" table to find a user with the specified email and password
    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
      // If the user's credentials are valid, set the session variables and redirect to the home page
      $row = mysqli_fetch_assoc($result);
      $_SESSION['user_id'] = $row['id'];
      $_SESSION['user_name'] = $row['name'];
      header('Location: index2.php');
      exit();
    } else {
      // If the user's credentials are not valid, display an error message
      $errors[] = 'Invalid email or password.';
    }

    // Close the database connection
    mysqli_close($conn);
  }

  // If there are errors, display them to the user
  foreach ($errors as $error) {
    echo '<p>' . $error . '</p>';
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="css/login.css">
</head>

<body>
  <h1>Login</h1>
  <form method="post">
    <label for="email">Email:</label>
    <input type="email" id="email" name="email"><br>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password"><br>

    <button type="submit">Login</button>

  </form>
</body>

</html>